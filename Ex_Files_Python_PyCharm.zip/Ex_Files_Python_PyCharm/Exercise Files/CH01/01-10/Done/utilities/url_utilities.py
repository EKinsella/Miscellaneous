def load_urls_from_file(file_path: str):
    #TODO: add the code needed to read the text file with the urls in it
    pass

def load_page(url: str):
    #TODO:  add the code that reads the url
    pass

def scrape_page(page_contents: str):
    #TODO:  analyze the text
    pass
